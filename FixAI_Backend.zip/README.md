# FixAI backend

Backend endpoint for AI vehicle diagnostics.

## Endpoints

- `GET /health` — server health check
- `POST /diagnose` — requires Firebase ID token in `Authorization: Bearer <token>`

Request JSON:

```json
{
  "vehicle": "Opel Astra J 1.7 CDTI 2010",
  "symptoms": "Gearbox whines and the gear lever moves while coasting"
}
```

The backend verifies the Firebase user, sends the diagnostic request to OpenAI, stores the answer under `users/{uid}/diagnoses`, and returns the diagnosis.

## Required secret

Set `OPENAI_API_KEY` only on the server. Never put it in the Android app.

Optional: `OPENAI_MODEL` (defaults to `gpt-5-mini`).

## Recommended deployment: Google Cloud Run

Deploy this `backend` directory to Cloud Run in the same Google Cloud/Firebase project (`fixai-a0246`). Give the Cloud Run runtime service account permission to use Firebase Authentication / Firestore via Application Default Credentials. Set `OPENAI_API_KEY` as a Cloud Run secret/environment variable.

After deployment, the Android app can call:

`https://YOUR-CLOUD-RUN-URL/diagnose`

with a Firebase ID token in the Authorization header.
